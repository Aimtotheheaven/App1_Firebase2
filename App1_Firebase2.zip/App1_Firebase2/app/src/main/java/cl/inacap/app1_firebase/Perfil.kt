package cl.inacap.app1_firebase

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity

class Perfil : AppCompatActivity() {

    private lateinit var tvusuperfil: TextView
    private lateinit var tvnomper: TextView
    private lateinit var tvemaper: TextView
    private lateinit var tvtipper: TextView
    private lateinit var tvconper: TextView
    private lateinit var btnvolper: Button
    private var usu: Usuario? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_perfil)

        tvusuperfil = findViewById(R.id.tvusuperfil)
        tvnomper = findViewById(R.id.tvnomper)
        tvemaper = findViewById(R.id.tvemaper)
        tvtipper = findViewById(R.id.tvtipper)
        tvconper = findViewById(R.id.tvconper)
        btnvolper = findViewById(R.id.btnvolper)

        usu = intent.getSerializableExtra("usu") as? Usuario

        tvusuperfil.text = "Bienvenido Usuario : " + (usu?.nombre ?: "")
        tvnomper.text = usu?.nombre?.lowercase() ?: ""
        tvemaper.text = usu?.email?.lowercase() ?: ""
        tvtipper.text = usu?.tipo?.lowercase() ?: ""
        tvconper.text = usu?.contraseña?.toString() ?: ""

        volver()
        desactivarFlecha()
    }

    fun volver() {
        btnvolper.setOnClickListener {
            val intent = Intent(this@Perfil, Menu::class.java)
            intent.putExtra("usu", usu)
            startActivity(intent)
        }
    }

    private fun desactivarFlecha() {
        onBackPressedDispatcher.addCallback(this) {}
    }
}