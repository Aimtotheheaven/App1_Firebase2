package cl.inacap.app1_firebase

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.addCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class Menu : AppCompatActivity() {

    private lateinit var tvusumenu: TextView
    private lateinit var btn1: Button
    private lateinit var btn2: Button
    private lateinit var btn3: Button
    private lateinit var btn4: Button
    private var usu: Usuario? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)

        tvusumenu = findViewById(R.id.tvusumenu)
        btn1 = findViewById(R.id.btn1)
        btn2 = findViewById(R.id.btn2)
        btn3 = findViewById(R.id.btn3)
        btn4 = findViewById(R.id.btn4)

        usu = intent.getSerializableExtra("usu") as? Usuario
        tvusumenu.text = "Bienvenido Usuario : " + (usu?.nombre ?: "")

        boton1()
        boton2()
        boton3()
        boton4()
        desactivarFlecha()
    }

    fun boton1() {
        btn1.setOnClickListener {
            val intent = Intent(this@Menu, ManipularESP32::class.java)
            intent.putExtra("usu", usu)
            startActivity(intent)
        }
    }

    fun boton2() {
        btn2.setOnClickListener {
            val intent = Intent(this@Menu, Acciones::class.java)
            intent.putExtra("usu", usu)
            startActivity(intent)
        }
    }

    fun boton3() {
        btn3.setOnClickListener {
            val intent = Intent(this@Menu, Perfil::class.java)
            intent.putExtra("usu", usu)
            startActivity(intent)
        }
    }

    fun boton4() {
        btn4.setOnClickListener {
            val a = AlertDialog.Builder(this@Menu)
            a.setTitle("Pregunta")
            a.setMessage("¿Desea Cerrar La Sesión?")
            a.setNegativeButton("Cancelar") { dialog, _ -> dialog.dismiss() }
            a.setPositiveButton("Aceptar") { _, _ ->
                val intent = Intent(this@Menu, Principal::class.java)
                startActivity(intent)
                finish()
            }
            a.setCancelable(false)
            a.show()
        }
    }

    private fun desactivarFlecha() {
        onBackPressedDispatcher.addCallback(this) {}
    }
}