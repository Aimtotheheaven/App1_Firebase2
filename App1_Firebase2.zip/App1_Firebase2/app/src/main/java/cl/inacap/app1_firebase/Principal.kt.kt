package cl.inacap.app1_firebase

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class Principal : AppCompatActivity() {

    private lateinit var txtusu: EditText
    private lateinit var txtcon: EditText
    private lateinit var btnini: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_principal)

        txtusu = findViewById(R.id.txtusu)
        txtcon = findViewById(R.id.txtcon)
        btnini = findViewById(R.id.btnini)

        botonLogin()
        desactivarFlecha()
    }

    fun botonLogin() {
        btnini.setOnClickListener {
            if (txtusu.text.toString().trim().isEmpty() || txtcon.text.toString().trim().isEmpty()) {
                Toast.makeText(this@Principal, "¡ Complete Los Campos Faltantes !", Toast.LENGTH_LONG).show()
            } else {
                val nom = txtusu.text.toString().uppercase()
                val con = txtcon.text.toString().toIntOrNull() ?: 0
                var estado = false

                val dbref = FirebaseDatabase.getInstance().getReference("Usuario")

                dbref.addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        for (x in snapshot.children) {
                            val dbNombre = x.child("nombre").value.toString()
                            val dbCon = x.child("contraseña").value.toString().toIntOrNull() ?: 0

                            if (nom.equals(dbNombre, ignoreCase = true) && con == dbCon) {
                                estado = true
                                val ema = x.child("email").value.toString()
                                val tip = x.child("tipo").value.toString()

                                val usu = Usuario(nom, ema, tip, con)
                                val intent = Intent(this@Principal, Menu::class.java)
                                intent.putExtra("usu", usu)
                                startActivity(intent)
                                break
                            }
                        }

                        if (!estado) {
                            txtusu.setText("")
                            txtcon.setText("")
                            Toast.makeText(this@Principal, "¡ Error de Usuario y/o Contraseña !", Toast.LENGTH_SHORT).show()
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Toast.makeText(this@Principal, "Error en la base de datos", Toast.LENGTH_SHORT).show()
                    }
                })
            }
        }
    }

    private fun desactivarFlecha() {
        onBackPressedDispatcher.addCallback(this) {}
    }
}