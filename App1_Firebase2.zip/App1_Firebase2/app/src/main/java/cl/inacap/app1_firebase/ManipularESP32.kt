package cl.inacap.app1_firebase

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class ManipularESP32 : AppCompatActivity() {

    private lateinit var tvusumanipular: TextView
    private lateinit var btnon: Button
    private lateinit var btnoff: Button
    private lateinit var btnvolman: Button
    private var usu: Usuario? = null

    private val dbRefBasurero = FirebaseDatabase.getInstance().getReference("BasureroInteligente")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_manipular_esp32)

        tvusumanipular = findViewById(R.id.tvusumanipular)
        btnon = findViewById(R.id.btnon)     // Abrir Tapa
        btnoff = findViewById(R.id.btnoff)   // Cerrar Tapa
        btnvolman = findViewById(R.id.btnvolman)

        usu = intent.getSerializableExtra("usu") as? Usuario
        tvusumanipular.text = "Bienvenido Usuario : " + (usu?.nombre ?: "")

        dbRefBasurero.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val dist = snapshot.child("distancia").value?.toString() ?: "0"
                val estado = snapshot.child("estado_tapa").value?.toString() ?: "CERRADA"

                tvusumanipular.text = "Usuario: ${usu?.nombre} | Distancia: ${dist}cm | Tapa: $estado"
            }

            override fun onCancelled(error: DatabaseError) {}
        })

        btnon.setOnClickListener {
            dbRefBasurero.child("estado_tapa").setValue("ABIERTA")
            Toast.makeText(this, "Tapa Abierta Remotamente", Toast.LENGTH_SHORT).show()
        }

        btnoff.setOnClickListener {
            dbRefBasurero.child("estado_tapa").setValue("CERRADA")
            Toast.makeText(this, "Tapa Cerrada", Toast.LENGTH_SHORT).show()
        }

        volver()
        desactivarFlecha()
    }

    fun volver() {
        btnvolman.setOnClickListener {
            val intent = Intent(this@ManipularESP32, Menu::class.java)
            intent.putExtra("usu", usu)
            startActivity(intent)
        }
    }

    private fun desactivarFlecha() {
        onBackPressedDispatcher.addCallback(this) {}
    }
}
